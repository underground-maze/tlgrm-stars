from django.utils import termcolors

blue = termcolors.make_style(opts=('bold'), fg='blue')
cyan = termcolors.make_style(opts=('bold'), fg='cyan')
green = termcolors.make_style(fg='green')
magenta = termcolors.make_style(opts=('bold'), fg='magenta')
red = termcolors.make_style(opts=('bold'), fg='red')
white = termcolors.make_style(opts=('bold',), fg='white')
yellow = termcolors.make_style(opts=('bold'), fg='yellow')
